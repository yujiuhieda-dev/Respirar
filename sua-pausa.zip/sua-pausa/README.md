# Sua Pausa
Micro-pausas de respiração (quadrada, 4-7-8, coerente) de 2 a 5 minutos. Site estático: abra `index.html` ou publique com GitHub Pages (Settings → Pages → branch `main`, pasta `/root`).
